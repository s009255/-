def isNumber(s):
  try:
    float(s)
    return True
  except ValueError:
    return False

def isInt(s):
  try:
    int(s)
    return True 
  except ValueError:
    return False

inp = []
calculate = []
result = []
error = 0


while 1: 
    print("0. 계산기 종료!!\n")
    print("1. 계산하기\n")
    print("2. 히스토리 조회\n")
    num_list = input("목록을 선택하시오 :")
    if num_list == "0":
        break

    
    if num_list == "1":
        while 1: 
            print("총 몇개의 숫자를 계산 하십니까?")
            num_cal = int(input())
            if not isInt(num_cal):
                print("숫자를 입력에 오류가 있습니다. 다시 입력해주세요!")
                continue
            while 1:
                print("계산할 값을 하나씩 입력해주세요")
                for i in range(0,2*num_cal-1):
                    inp = input()
                    calculate.append(inp)
                for i in range(0,2*num_cal-1): 
                    if i%2 == 0:
                        if not isNumber(calculate[i]):
                            print("계산기 입력에 오류가 있습니다. 다시 입력해주세요!")
                            del calculate[:]
                            continue
                    elif i%2 == 1:
                        if isNumber(calculate[i]):
                            print("계산기 입력에 오류가 있습니다. 다시 입력해주세요!")
                            del calculate[:]
                for i in range(0,num_cal-1):
                    if calculate[2*i+1] == "/":
                        continue
                    elif calculate[2*i+1] == "*":
                        continue
                    elif calculate[2*i+1] == "-":
                        continue
                    elif calculate[2*i+1] == "+":
                        continue
                    else:
                        error = 1;
                if error == 1:
                    error = 0
                    print("계산기 입력에 오류가 있습니다. 다시 입력해주세요!")
                    continue        

                for i in range(0,num_cal-1):
                    if calculate[2*i+1] == "/":
                        if calculate[2*i] == ".":
                            temp = temp / float(calculate[2*i+2])
                            calculate[2*i+2] = "."
                            
                        elif calculate[2*i+2] == ".":
                            temp = float(calculate[2*i]) / temp
                            calculate[2*i] = "."
                        else:
                            temp = float(calculate[2*i]) / float(calculate[2*i+2])
                            calculate[2*i+2] = "."
                            calculate[2*i] = "."
                        calculate[2*i+1] = "."

                for i in range(0,num_cal-1):        
                    if calculate[2*i+1] == "*":
                        if calculate[2*i] == ".":
                            temp = temp * float(calculate[2*i+2])
                            calculate[2*i+2] = "."
                        elif calculate[2*i+2] == ".":
                            temp = float(calculate[2*i]) * temp
                            calculate[2*i] = "."
                        else:    
                            temp = float(calculate[2*i]) * float(calculate[2*i+2])
                            calculate[2*i+2] = "."
                            calculate[2*i] = "."
                        calculate[2*i+1] = "."
                for i in range(0,num_cal-1):            
                    if calculate[2*i+1] == "-":
                        if calculate[2*i] == ".":
                            temp = temp - float(calculate[2*i+2])
                            calculate[2*i+2] = "."
                        elif calculate[2*i+2] == ".":
                            temp = float(calculate[2*i]) - temp
                            calculate[2*i] = "."
                        else:  
                            temp = float(calculate[2*i]) - float(calculate[2*i+2])
                            calculate[2*i+2] = "."
                            calculate[2*i] = "."
                        calculate[2*i+1] = "."
                for i in range(0,num_cal-1): 
                    if calculate[2*i+1] == "+":
                        if calculate[2*i] == ".":
                            temp = temp + float(calculate[2*i+2])
                            calculate[2*i+2] = "."
                        elif calculate[2*i+2] == ".":
                            temp = float(calculate[2*i]) + temp
                            calculate[2*i] = "."
                        else:    
                            temp = float(calculate[2*i]) + float(calculate[2*i+2])
                            calculate[2*i+2] = "."
                            calculate[2*i] = "."
                        calculate[2*i+1] = "."
                break
            print("계산결과 : ", temp)
            result.append(temp)
            temp = 0
            del calculate[:]
            break
        
            

    if num_list == "2":
        print(result)

    else:
        ("유효하지 않는 목록입니다!")
        

    
##a = float(input('첫 번째 숫자를 입력하시오 : '))
##b = float(input('두 번째 숫자를 입력하시오 : '))
